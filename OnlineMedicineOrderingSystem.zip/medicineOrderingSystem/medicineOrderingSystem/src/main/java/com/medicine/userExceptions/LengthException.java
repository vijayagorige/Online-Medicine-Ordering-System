package com.medicine.userExceptions;

public class LengthException extends Exception{

	public LengthException() {
		super();
	}


	public LengthException(String message) {
		super(message);
	}

}
