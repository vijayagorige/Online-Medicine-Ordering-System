package com.medicine.medicineservice;
import java.util.List;
import com.medicine.entity.Admin;
import com.medicine.userExceptions.UserFoundException;
import com.medicine.userExceptions.UserNotFoundException;


public interface AdminService {
		
//	 	List<Admin> getAllRecords() throws UserNotFoundException;
//		
//		Admin saveAdmin(Admin admin)  throws UserFoundException;
//		
//		Admin updateAdmin(Admin admin) throws UserNotFoundException;
//		
//		String deleteAdmin(String id) throws UserNotFoundException;

		Admin getAdmin(String id) throws UserNotFoundException;
}
