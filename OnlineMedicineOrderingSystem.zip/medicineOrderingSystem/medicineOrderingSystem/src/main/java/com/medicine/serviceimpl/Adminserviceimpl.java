package com.medicine.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicine.entity.Admin;
import com.medicine.medicineservice.AdminService;
import com.medicine.repository.AdminRepository;
import com.medicine.userExceptions.UserFoundException;
import com.medicine.userExceptions.UserNotFoundException;

@Service
public class Adminserviceimpl implements AdminService{
	
	@Autowired
	private AdminRepository adminRepository;

//	@Override
//	public List<Admin> getAllRecords()throws UserNotFoundException {
//		List<Admin> adminlist=adminRepository.findAll();
//		if(adminlist.isEmpty()) 
//		{
//			throw new UserNotFoundException("NO records are there.Please create user 1st!");
//		}
//		else
//			return adminlist;
//	}
//
//	@Override
//	public Admin saveAdmin(Admin admin) throws UserFoundException {
//		Optional<Admin> existadmin=adminRepository.findById(admin.getLoginid());
//		if(existadmin.isPresent())
//		{
//			throw new UserFoundException("This admin already exist!please login with other loginid");
//		}
//		else
//			return adminRepository.save(admin);	
//	}

	@Override
	public Admin getAdmin(String id) throws UserNotFoundException{
		Optional<Admin> checkadmin=adminRepository.findById(id);
		if(checkadmin.isPresent())
		{
			return adminRepository.findById(id).get();
		}
		else
		{
			throw new UserNotFoundException("There is no admin with this id");
		}
	}

//	@Override
//	public Admin updateAdmin(Admin admin) throws UserNotFoundException{
//		Optional<Admin> checkadmin=adminRepository.findById(admin.getLoginid());
//		if(checkadmin.isPresent())
//		{
//			return adminRepository.save(admin);
//		}
//		else
//		{
//			throw new UserNotFoundException("There is no admin with this id");
//		}
//	}
//
//	@Override
//	public String deleteAdmin(String id) throws UserNotFoundException{
//		Optional<Admin> checkadmin=adminRepository.findById(id);
//		if(checkadmin.isPresent())
//		{
//			adminRepository.deleteById(id);
//			return "Record deleted";
//		}
//		else
//		{
//			throw new UserNotFoundException("There is no admin with this id");
//		}
//		
//	}
}
