package com.medicine.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicine.entity.Admin;
import com.medicine.serviceimpl.Adminserviceimpl;
import com.medicine.userExceptions.UserFoundException;
import com.medicine.userExceptions.UserNotFoundException;

@CrossOrigin(origins="http://localhost:4200/")
@RestController
public class AdminController {
	
	@Autowired
    Adminserviceimpl adminserviceimpl;	
	
	
	@GetMapping("/admin")
	public ResponseEntity<List<Admin>>getAllAdmins() throws UserNotFoundException
	{
		List<Admin> newadmin=adminserviceimpl.getAllRecords();
		return new ResponseEntity<>(newadmin,HttpStatus.OK);
	}
	
	@PostMapping("/admin")
	public ResponseEntity<Admin> addAdmin(@RequestBody Admin admin) throws UserFoundException 
	{
		Admin newadmin=adminserviceimpl.saveAdmin(admin);
		return new ResponseEntity<>(newadmin,HttpStatus.CREATED);
	}
		
	
	@GetMapping("/admin/{id}")
	public ResponseEntity<Admin> getAdminById(@PathVariable String id) throws UserNotFoundException{

		Admin admin=adminserviceimpl.getAdmin(id);
		return new ResponseEntity<>(admin,HttpStatus.OK);

	}
	
	@PutMapping("/admin/{id}")
	public ResponseEntity<Admin> updateAdmin(@PathVariable String id,@RequestBody Admin admin) throws UserNotFoundException{
		Admin updateadmin=new Admin();
		updateadmin.setLoginid(id);
		updateadmin.setPassword(admin.getPassword());
		Admin updateadminnew=adminserviceimpl.updateAdmin(admin);
		return new ResponseEntity<>(updateadminnew,HttpStatus.OK);
	}
	
	@DeleteMapping("/admin/{id}")
	public ResponseEntity<String> deleteAdmin(@PathVariable String id) throws UserNotFoundException
	{
		String delAdmin= adminserviceimpl.deleteAdmin(id);
		return new ResponseEntity<>(delAdmin,HttpStatus.OK);
	}	
}
